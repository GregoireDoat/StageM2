# TO DO

- Bargmann

- Faire la partie 3
    - code des résultats
    - présentation des résultats
    - le gros blabla

- Plan pour l'oral

- Fix les pb de la partie 2 
    - Stokes & géodésiqueq

- Annexes
    - Retaper l'annexe 1.A
    - Bloch au propre (vidéo double cover)
    - VDC ?

- Figure
    - URGENT : finir les dessins
    - si le temps : tikzifier les plots